# fun
A compilation of quizzes, puzzles and a steganography calculator. Note that there are still quizzes and more under development!!
